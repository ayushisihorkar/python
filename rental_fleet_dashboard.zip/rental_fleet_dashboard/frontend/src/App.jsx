import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Dashboard from './pages/Dashboard';
import VehicleDetail from './pages/VehicleDetail';
import './styles/tailwind.css';

function App() {
  return (
    <Router>
      <div className="App">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/vehicle/:id" element={<VehicleDetail />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App; 