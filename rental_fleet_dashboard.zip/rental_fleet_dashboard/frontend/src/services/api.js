import axios from 'axios';

// Create axios instance with base configuration
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:8000',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor for logging
api.interceptors.request.use(
  (config) => {
    console.log(`API Request: ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    console.error('API Request Error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response) => {
    console.log(`API Response: ${response.status} ${response.config.url}`);
    return response;
  },
  (error) => {
    console.error('API Response Error:', error.response?.data || error.message);
    return Promise.reject(error);
  }
);

// Vehicle API calls
export const vehicleAPI = {
  // Get all vehicles
  getVehicles: async (params = {}) => {
    const response = await api.get('/vehicles', { params });
    return response.data;
  },

  // Get specific vehicle
  getVehicle: async (vehicleId) => {
    const response = await api.get(`/vehicles/${vehicleId}`);
    return response.data;
  },

  // Create new vehicle
  createVehicle: async (vehicleData) => {
    const response = await api.post('/vehicles', vehicleData);
    return response.data;
  },

  // Update vehicle
  updateVehicle: async (vehicleId, vehicleData) => {
    const response = await api.put(`/vehicles/${vehicleId}`, vehicleData);
    return response.data;
  },

  // Delete vehicle
  deleteVehicle: async (vehicleId) => {
    const response = await api.delete(`/vehicles/${vehicleId}`);
    return response.data;
  },

  // Get vehicle telemetry
  getVehicleTelemetry: async (vehicleId, limit = 100) => {
    const response = await api.get(`/vehicles/${vehicleId}/telemetry`, {
      params: { limit }
    });
    return response.data;
  },

  // Get latest telemetry
  getLatestTelemetry: async (vehicleId) => {
    const response = await api.get(`/vehicles/${vehicleId}/telemetry/latest`);
    return response.data;
  },

  // Submit telemetry data
  submitTelemetry: async (telemetryData) => {
    const response = await api.post('/telemetry', telemetryData);
    return response.data;
  },

  // Get vehicle health analysis
  getVehicleHealth: async (vehicleId) => {
    const response = await api.get(`/vehicles/${vehicleId}/health`);
    return response.data;
  },

  // Get vehicle health history
  getVehicleHealthHistory: async (vehicleId, limit = 50) => {
    const response = await api.get(`/vehicles/${vehicleId}/health/history`, {
      params: { limit }
    });
    return response.data;
  },

  // Get vehicle analytics
  getVehicleAnalytics: async (vehicleId) => {
    const response = await api.get(`/analytics/vehicles/${vehicleId}`);
    return response.data;
  }
};

// Maintenance API calls
export const maintenanceAPI = {
  // Get maintenance tasks
  getMaintenanceTasks: async (params = {}) => {
    const response = await api.get('/maintenance/tasks', { params });
    return response.data;
  },

  // Create maintenance task
  createMaintenanceTask: async (taskData) => {
    const response = await api.post('/maintenance/tasks', taskData);
    return response.data;
  },

  // Update maintenance task
  updateMaintenanceTask: async (taskId, taskData) => {
    const response = await api.put(`/maintenance/tasks/${taskId}`, taskData);
    return response.data;
  }
};

// Booking API calls
export const bookingAPI = {
  // Get bookings
  getBookings: async (params = {}) => {
    const response = await api.get('/bookings', { params });
    return response.data;
  },

  // Get specific booking
  getBooking: async (bookingId) => {
    const response = await api.get(`/bookings/${bookingId}`);
    return response.data;
  },

  // Create booking
  createBooking: async (bookingData) => {
    const response = await api.post('/bookings', bookingData);
    return response.data;
  },

  // Update booking
  updateBooking: async (bookingId, bookingData) => {
    const response = await api.put(`/bookings/${bookingId}`, bookingData);
    return response.data;
  },

  // Cancel booking
  cancelBooking: async (bookingId) => {
    const response = await api.delete(`/bookings/${bookingId}`);
    return response.data;
  }
};

// Workshop API calls
export const workshopAPI = {
  // Get all workshops
  getWorkshops: async () => {
    const response = await api.get('/workshops');
    return response.data;
  },

  // Get specific workshop
  getWorkshop: async (workshopId) => {
    const response = await api.get(`/workshops/${workshopId}`);
    return response.data;
  },

  // Get workshops by service
  getWorkshopsByService: async (service) => {
    const response = await api.get(`/workshops/service/${service}`);
    return response.data;
  }
};

// Alert API calls
export const alertAPI = {
  // Get alerts
  getAlerts: async (params = {}) => {
    const response = await api.get('/alerts', { params });
    return response.data;
  },

  // Mark alert as read
  markAlertRead: async (alertId) => {
    const response = await api.put(`/alerts/${alertId}/read`);
    return response.data;
  }
};

// Analytics API calls
export const analyticsAPI = {
  // Get fleet analytics
  getFleetAnalytics: async () => {
    const response = await api.get('/analytics/fleet');
    return response.data;
  },

  // Generate fleet report
  generateFleetReport: async (startDate, endDate) => {
    const response = await api.get('/reports/fleet', {
      params: { start_date: startDate, end_date: endDate }
    });
    return response.data;
  }
};

// System API calls
export const systemAPI = {
  // Get system status
  getSystemStatus: async () => {
    const response = await api.get('/system/status');
    return response.data;
  },

  // Health check
  healthCheck: async () => {
    const response = await api.get('/health');
    return response.data;
  }
};

// Emergency API calls
export const emergencyAPI = {
  // Handle emergency
  handleEmergency: async (vehicleId, emergencyData) => {
    const response = await api.post('/emergency', {
      vehicle_id: vehicleId,
      ...emergencyData
    });
    return response.data;
  }
};

// Utility functions
export const apiUtils = {
  // Handle API errors
  handleError: (error) => {
    if (error.response) {
      // Server responded with error status
      return {
        message: error.response.data?.detail || error.response.data?.message || 'An error occurred',
        status: error.response.status,
        data: error.response.data
      };
    } else if (error.request) {
      // Request was made but no response received
      return {
        message: 'No response from server. Please check your connection.',
        status: 0,
        data: null
      };
    } else {
      // Something else happened
      return {
        message: error.message || 'An unexpected error occurred',
        status: 0,
        data: null
      };
    }
  },

  // Format date for API
  formatDate: (date) => {
    if (typeof date === 'string') return date;
    if (date instanceof Date) return date.toISOString().split('T')[0];
    return date;
  },

  // Parse API response
  parseResponse: (response) => {
    if (response.success === false) {
      throw new Error(response.message || 'API request failed');
    }
    return response.data || response;
  }
};

export default api; 